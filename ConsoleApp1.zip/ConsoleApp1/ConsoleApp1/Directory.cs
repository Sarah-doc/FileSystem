﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Directory : DirectoryEntry
    {
       public List<DirectoryEntry> DirOrFiles;
       public Directory parent;
        public Directory()
        {

        }
        public Directory(Directory parent, byte attr,int firstCluster, char[] dir_name)
        : base(dir_name, attr, firstCluster)
        {
            this.dir_name = dir_name;
            this.dir_attr = attr;
            this.dir_firstCluster = firstCluster;
            if (parent!=null)
            {
                this.parent = parent;
            }
            DirOrFiles = new List<DirectoryEntry>();
        }
        static int lastCluster, clusterIndex;
        public void writeDirectory()
        {
            DirectoryEntry Old = GetDirectoryEntry();

            byte[] df = new byte[DirOrFiles.Count * 32];

            for (int i = 0; i < DirOrFiles.Count; i++)
            {
                byte[] b = DirectoryEntry.getBytes(DirOrFiles[i]);

                for (int j = i * 32, k = 0; k < b.Length; k++, j++)
                {
                    df[j] = b[k];
                }
            }



            //int clusterIndex;
            if (this.dir_firstCluster != 0)
            {
                clusterIndex = this.dir_firstCluster;
            }
            else
            {
                clusterIndex = FatTable.getAvailableblock();
                this.dir_firstCluster = clusterIndex;
            }
            for (int i = 0; i < df.Length; i += 1024)
            {
                byte[] s = df.Skip(i).Take(1024).ToArray();
                VirtualDisk.writeBlock(s, clusterIndex);
                FatTable.setNext(clusterIndex,0);
            }
            FatTable.setNext(clusterIndex, -1);
            if (lastCluster != -1)
            {
                lastCluster = clusterIndex;
                clusterIndex=FatTable.getAvailableblock();   
            }
            //DirectoryEntry Old = new DirectoryEntry();
            DirectoryEntry New = GetDirectoryEntry();
            if (this.parent!=null)
            {
                this.parent.updateDirectory(Old, New);
                this.parent.writeDirectory();
            }
            FatTable.Write_Fat();
        }
        public void readDirectory()
        {
            if (this.dir_firstCluster != 0)
            {
                DirOrFiles = new List<DirectoryEntry>();
                int cluster = this.dir_firstCluster;
                int next = FatTable.getNext(cluster);
                List<byte> lst = new List<byte>(); 
                do
                {
                    lst.AddRange(VirtualDisk.readBlock(cluster));
                    cluster = next;
                    if (cluster != -1)
                    {
                        next = FatTable.getNext(cluster);
                    }
                }
                while (next != -1);
                for (int i = 0; i < lst.Count; i++)
                {
                    byte[] b = new byte[32];
                    for (int k = i * 32, m = 0; m < b.Length && k < lst.Count(); k++)
                    {
                        b[m] = lst[k];
                    }
                    if (b[0] == 0)
                        break;

                    DirectoryEntry d = DirectoryEntry.getDirectoryEntry(b);
                    DirOrFiles.Add(d);

                }
            }
        }
        public int searchDirectory(char[] name)
        {
            readDirectory();
            for (int i = 0; i < DirOrFiles.Count; i++)
            {
                char[] namedir = DirOrFiles[i].dir_name;
                if (namedir == name)
                {
                    return i;
                }
            }
            return -1;
        }
        public void AddEntry(DirectoryEntry d)
        {
            DirOrFiles.Add(d);
            writeDirectory();
        }
        public int sizeOfDisk()
        {
            int size = 0;
            if (this.dir_firstCluster != 0)
            {
                int cluster = this.dir_file_size;
                int next = FatTable.getNext(cluster);
                do
                {
                    size++;
                    cluster = next;
                    if (cluster!=-1)
                    {
                        next= FatTable.getNext(cluster);
                    }
                } while (cluster != -1);    
            }
            return size;
        }
         

        public void updateDirectory(DirectoryEntry old, DirectoryEntry New)
        {

            readDirectory();
            int index = searchDirectory(old.dir_name);
            if (index != -1)
            {
                DirOrFiles.RemoveAt(index);
                DirOrFiles.Add(New);
                writeDirectory();
            }

        }
        public  void deleteDirectory(DirectoryEntry entry)
        {
            if (dir_firstCluster != 0)
            {
                int cluster = this.dir_firstCluster;
                int next = FatTable.getNext(cluster);
                do
                {
                    FatTable.setNext(cluster, 0);
                    cluster = next;
                    if (cluster != -1)
                    next = FatTable.getNext(cluster);
                } while (cluster != -1);
                if (this.parent != null)
                {
                    parent.readDirectory();
                    int index = this.parent.searchDirectory(this.dir_name);
                    if (index != -1)
                    {
                        this.parent.DirOrFiles.RemoveAt(index);
                        this.parent.writeDirectory();
                    }
                }
            }
            FatTable.Write_Fat();//?????????????????
        }
        public void RemoveEntry(DirectoryEntry directory)///////////////////
        {
            readDirectory();
            int index= searchDirectory(directory.dir_name);
            if (index!=-1)
            {
                DirOrFiles.RemoveAt(index);
                writeDirectory();
            }
            else
            {
                Console.WriteLine("No such file/dir");
            }
        }
        public void empty()
        {
            if (this.dir_firstCluster!=0)
            {

                int cluster = this.dir_file_size;
                int next = FatTable.getNext(cluster);
                if (cluster ==5 && next==0)
                {
                    return;
                }
                do
                {
                    FatTable.setNext(cluster, 0);
                    cluster= next;
                    if (cluster!=-1)
                    {
                        next= FatTable.getNext(cluster);
                    }
                } while (cluster != -1);

            }
        }
        public void deletedir()
        {
            if (Program.currentDirectory ==this)
            {
                Console.WriteLine("current dir busy");
                return;
            }
            empty();
            if (this.parent!=null)
            {
                this.parent.RemoveEntry(GetDirectoryEntry());
            }
            else
            {
                Console.WriteLine("Has Deleted");
            }
            
        }
    }
}
