﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class DirectoryEntry
    {
        public char[] dir_name = new char[11];
        public byte dir_attr;
        public byte[] dir_empty= new byte[12];
        public int dir_firstCluster;
        public int dir_file_size;

        public DirectoryEntry()
        {
        }

        public DirectoryEntry(char[] dir_name, byte dir_attr, int dir_firstCluster)
        {
            this.dir_name = dir_name;
            if (dir_name.Length<= 11)
            {
                //dir_name = new char[11];
            }
            this.dir_attr = dir_attr;
            this.dir_firstCluster = dir_firstCluster;

        }
       
        public static byte[] getBytes(DirectoryEntry entry)//take directoryentry return bytes 
        {
            byte[] b = new byte[32];
            Buffer.BlockCopy(entry.dir_name, 0, b, 0, 11);
            b[12] = entry.dir_attr;
            Buffer.BlockCopy(entry.dir_empty, 0, b, 12, 12);
            byte[] fc = BitConverter.GetBytes(entry.dir_firstCluster);
            Buffer.BlockCopy(fc, 0, b, 24, 4);
            byte[] size = BitConverter.GetBytes(entry.dir_file_size);
            Buffer.BlockCopy(entry.dir_empty, 0, b, 28, 4);
            return b;
        }
        public static DirectoryEntry getDirectoryEntry(byte[] b) //take array of byte return directoryentry
        {
            DirectoryEntry dir1 = new DirectoryEntry(); //dir1?
            Buffer.BlockCopy(b, 0, dir1.dir_name, 0, 11);
            dir1.dir_attr = b[12];
            Buffer.BlockCopy(b, 24, dir1.dir_empty, 12, 12);
            byte[] fc = new byte[4];
            Buffer.BlockCopy(b, 24, fc, 0, 4);
            dir1.dir_firstCluster = BitConverter.ToInt32(fc, 0);
            byte[] size = new byte[4];
            Buffer.BlockCopy(b, 28, size, 0, 4);
            dir1.dir_file_size = BitConverter.ToInt32(size, 0);
            return dir1;
        }
        public DirectoryEntry GetDirectoryEntry() //take (from class itself)none return directoryentry // 
        {
            DirectoryEntry d = new DirectoryEntry(dir_name, dir_attr, dir_firstCluster);
            d.dir_name = this.dir_name;
            d.dir_attr = this.dir_attr;
            d.dir_file_size = this.dir_file_size;
            return d;
        }
    }
}
