﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class FatTable
    {
       public static int[] fat_table;
        static FileStream file;
        public const string fileName = "file1.txt";
        FatTable()
        {
            fat_table = new int[1024];
        }
       public static void initializeFat()
        {
            for (int i = 0; i <fat_table.Length;i++ )
            {
                if (i<5)
                {
                    fat_table[i] = -1;
                }
                else
                {
                    fat_table[i] = 0;
                }
            }
        }
        public static void Write_Fat()//?
        {
            file = new FileStream(fileName, FileMode.Open, FileAccess.Write);
            file.Seek(1024, SeekOrigin.Begin);
            byte[] byt = new byte[4096];
            Buffer.BlockCopy(fat_table, 0, byt, 0, byt.Length);
           // file.Write(b, 0, b.Length);
            for (int i = 0; i < 1024; i++)
            {
                byte[] block = new byte[1024];
                for (int j = i * 1024, k = 0; k < 1024; k++, j++)
                {
                    block[k] = byt[j];
                }

                VirtualDisk.writeBlock(byt, i+1);
            }
            file.Flush();
            file.Close();
        }
        public static byte[] readFat()
        {
            byte[] bytes = new byte[4096];
            for (int i=1; i<5 ;i++)
            {
                byte[] rblock = VirtualDisk.readBlock(i+1);
                for (int j = i * 1024, k = 0; k < 1024; k++, j++)
                {
                    bytes[i] = rblock[k];
                }
                Buffer.BlockCopy(bytes, 0, fat_table, 0, bytes.Length);
            }
            return bytes;
        }
        public static int getAvailableblock()
        {
            for (int i=0; i<fat_table.Length;i++ )
            {
                if(fat_table[i] == 0)
                {
                    return i;
                }
            }
            return -1;
        }
        public static int CountFreeBlocks()
        {
            int count = 0;
            for (int i = 0; i <fat_table.Length;i++)
            {
                 if (fat_table[i] == 0)
                {
                    count++;
                }
            }
            return count;
        }
        public static int getNext(int index)
        {
            return fat_table[index];
        }
        public static void setNext(int index, int next)
        {
            fat_table[index] = next;
        }
        //public static void updateFat()
        //{
            
        //}
        public static void printFat()
        {
           byte[] b= readFat();
            for (int i=0; i<b.Length; i++)
            {
                Console.WriteLine(b[i]);
            }
        }
       
    }
}
