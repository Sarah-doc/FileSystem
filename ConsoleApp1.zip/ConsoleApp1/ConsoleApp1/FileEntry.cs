﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class FileEntry : DirectoryEntry
    {
        Directory parent;
        string content;
        public FileEntry()
        {

        }
        public FileEntry(char[] dir_name, byte dir_attr, int dir_firstCluster) :
            base(dir_name, dir_attr, dir_firstCluster)
        {
            this.dir_name = dir_name;
            this.dir_attr = dir_attr;
            this.dir_firstCluster = dir_firstCluster;
        }
        public FileEntry GetFileEntry()
        {
            FileEntry f = new FileEntry(dir_name,  dir_attr, dir_firstCluster);
            f.dir_name = this.dir_name;
            f.dir_attr = this.dir_attr;
            f.dir_file_size = this.dir_file_size;
            return f;

        }
        public static void writeFileContent()
        {

        }
        public static void readFileContent()
        {
            //read bytrs from disk .. convert to string .. put in content attr
        }
        public void deletefile()
        {
            if (Program.currentFile == this)
            {
                Console.WriteLine("current dir busy");
                return;
            }
            emptyClusters();
            if (this.parent != null)
            {
                this.parent.RemoveEntry(GetDirectoryEntry());
            }
            else
            {
                Console.WriteLine("Has Deleted");
            }
        }
        public void emptyClusters()
        {
            if (this.dir_firstCluster != 0)
            {

                int cluster = this.dir_file_size;
                int next = FatTable.getNext(cluster);
                if (cluster == 5 && next == 0)
                {
                    return;
                }
                do
                {
                    FatTable.setNext(cluster, 0);
                    cluster = next;
                    if (cluster != -1)
                    {
                        next = FatTable.getNext(cluster);
                    }
                } while (cluster != -1);

            }
        }
        public int getsizeOfDisk()
        {
            int size = 0;
            if (this.dir_firstCluster != 0)
            {
                int cluster = this.dir_file_size;
                int next = FatTable.getNext(cluster);
                do
                {
                    size++;
                    cluster = next;
                    if (cluster != -1)
                    {
                        next = FatTable.getNext(cluster);
                    }
                } while (cluster != -1);
            }
            return size;
        }
        public void printContent()
        {
            readFileContent();
            for (int i=0; i<content.Length;i++)
            {
                Console.WriteLine(content[i]);
            }
        }
    }
}
