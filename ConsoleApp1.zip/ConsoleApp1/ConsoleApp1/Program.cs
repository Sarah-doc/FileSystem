﻿using System;
using System.IO;
namespace ConsoleApp1
{
    class Program
    {
        public static Directory currentDirectory;
        public static string currentPath;
        public static FileEntry currentFile;



        public void md(char[] name)
        {

            if (currentDirectory.searchDirectory(name) == -1) ;
            {
                DirectoryEntry d = new DirectoryEntry(name, 0x01, 0);
                currentDirectory.DirOrFiles.Add(d);
                currentDirectory.writeDirectory();
                if (currentDirectory.parent != null)
                {
                    currentDirectory.updateDirectory(currentDirectory.GetDirectoryEntry());//******
                }
                else
                {
                    Console.WriteLine("This File Already Exist");
                }
            }
        }
        public void rd(char[] name)
        {
            int index = currentDirectory.searchDirectory(name);
            if (index != -1)
            {
                int fc = currentDirectory.DirOrFiles[index].dir_firstCluster;
                Directory d = new Directory(currentDirectory, 0x01, fc,name );
               d.deleteDirectory(d);//*********
            }
            else
            {
                Console.WriteLine("Directory Does not exit");
            }

        }
        public void cd(char[] name)
        {
            int index = currentDirectory.searchDirectory(name);
            if (index != -1)
            {
                byte attr = currentDirectory.DirOrFiles[index].dir_attr;
                if (attr == 0x01)
                {
                    int fc = currentDirectory.DirOrFiles[index].dir_firstCluster;
                    Directory d = new Directory(currentDirectory, 0x01, fc, name);
                    currentDirectory = d;
                    currentPath += "/" + name;
                    currentDirectory.readDirectory();
                }
            }
            else
            {
                Console.WriteLine("The specified file does not exist");
            }
        }

        public static void commandLine()
        {
            while (true)
            {
                // Get the current directory.
                string path = "C:/Users/ALL IN ONE/source/repos/ConsoleApp1/ConsoleApp1";
                Console.WriteLine("The current directory is {0}>", path);
                //get input from user
                string input = Console.ReadLine();
                string[] parse = input.Split(" ");
                //array of valid commands 
                //string[] commands;
                //commands = new string[] { "help", "cls", "quit" };
                //for (int i = 0; i < commands.Length; i++)
                //{ss
                //    if (input == commands[i])
                //    {
                if (input == "help" || parse[0] == "help")
                {
                    Console.WriteLine("cd        Change the current default directory to ");
                    Console.WriteLine("cls       Clear the screen");
                    Console.WriteLine("dir       List the contents of directory ");
                    Console.WriteLine("quit      Quit the shell");

                }
                else if (input == "cls" || parse[0] == "cls")
                {
                    Console.Clear();
                }
                else if (input == "quit" || parse[0] == "quit")
                {
                    Environment.Exit(0);
                }
            }
        }
        static void Main(string[] args)
        {
           char[] Path = new char[] {'K'};
            Directory root = new Directory(null,0x10,5,Path);
            currentDirectory = new Directory(currentDirectory, 0x10, 5, Path);
            currentDirectory.readDirectory();
            currentDirectory.writeDirectory();
            string input = "";
            string str = new string(currentDirectory.dir_name);
            while(true)
            {
                Console.WriteLine("{0}"+str+"/");
                input = Console.ReadLine();
            }
        }
    }
}

