﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class VirtualDisk
    {
       public const string fileName = "file7.txt";
        public static StreamWriter disk;
        public static FileStream f1;
        public static void InitializeDisk()
        {
            if (!System.IO.File.Exists(fileName))
            {
                // check if exist?????????????????????????
                //if yes get fat table 
                //instance of directory 
                //read of directory
                disk = new StreamWriter(fileName);
                for (int i = 0; i < 1024; i++)
                {
                    disk.Write('0');
                }
                for (int i = 0; i < 1024 * 4; i++)
                {
                    disk.Write('*');
                }
                for (int i = 0; i < 1019 * 1024; i++)
                {
                    disk.Write('#');
                }
                //byte[] bytes = new byte[1024];
                FatTable.initializeFat();
                FatTable.Write_Fat();
                Console.WriteLine("created successfully");
            }
            else
            {
                f1 = new FileStream(fileName, FileMode.Open, FileAccess.Write, FileShare.None);
            }
            disk.Flush();
            disk.Close();
        }
        public static void writeBlock(byte[] data, int index)
        {
            //open file
            f1=new FileStream(fileName, FileMode.Open, FileAccess.Write);
            //seek to 124*index
            f1.Seek(1024*index, SeekOrigin.Begin);
            //write data
            f1.Write(data, 0, data.Length);
            f1.Flush();
            f1.Close();
        }
        public static byte[] readBlock(int index)//?
        {
            //open file
            f1 = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            //Seek to index
            f1.Seek(index, SeekOrigin.Begin);
            byte[] result = new byte[1024]; // بقرأ ايه؟
            f1.Read(result, 0, result.Length);
            return result;
        }
        public static int getLogicalFreeSpace()
        {
            return FatTable.CountFreeBlocks();
        }
        
    }
}
